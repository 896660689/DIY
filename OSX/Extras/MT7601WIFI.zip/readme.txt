使用步骤：
1、安装 RT2870USBWirelessDriver.kext 到 /System/Library/Extensions 
2、安装 RaWLAPI.framework 到 /Library/Frameworks 
3、安装 WirelessUtility 到 /Applications，并设置为自动启动
4、可选：双击安装 DWA-140WirelessUtility.prefPane
