<?php
const CLIENT_ID="XXXXXXclientid";
const CLIENT_SECRET="XXXXXXsecret";
const URL="http://XXXXXX:8123";
const PASS=""

?>
